# Weather Data Storage

This program reads real-world weather data from a CSV file (`Weather Training Data.csv`) and stores it in a Python dictionary. The date is used as the key, and the rest of the weather data for that date is stored as a list of values.

## Features

- **Data Storage:** The program processes weather data from a CSV file and organizes it into a dictionary, where each key is a date and each value is a list of corresponding weather data.
- **Error Handling:** If the specified CSV file is not found, the program will return a "File Not Found" message.

## Prerequisites

- Python 3.12
- A CSV file named `Weather Training Data.csv` (because the file name within the program is not editable) containing weather data, with the first column as the date.

## Installation

1. Ensure you have Python 3.12 installed on your system.
2. Place the `Weather Training Data.csv` file in the same directory as the script, if it's not there already.

## Usage

To run the program, execute the following command in your terminal:

```bash
python3 main.py
```

## Example Output

If the CSV file is successfully read, the program will output the dictionary containing the weather data, with dates as keys.

## Code Overview

- `store_weather_data()`: Reads the .csv file and stores the weather data in a dictionary.
- `main()`: Calls `store_weather_data()` and prints the resulting dictionary.

## Pydoc Instructions 

- To create a document, execute the following command in your terminal:

```bash
python3 -m pydoc -w main
```

- To run the newly created .html file, execute the following command in your terminal:

```bash
open main.html
```
